package com.example.homework03

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel


data class ImgData(var imgId: Int) {
    companion object {
        val imgListSaver = listSaver<ImgData, Any>(
            save = { listOf(it.imgId) },
            restore = { ImgData(it[0] as Int) }
        )
    }
}

class ImgViewModel : ViewModel() {
    var imglist = mutableStateListOf<ImgData>()
        private set
    init {
        imglist.add(ImgData(R.drawable.arms))
        imglist.add(ImgData(R.drawable.eyebrows))
        imglist.add(ImgData(R.drawable.glasses))
        imglist.add(ImgData(R.drawable.mouth))
        imglist.add(ImgData(R.drawable.nose))

        imglist.add(ImgData(R.drawable.ears))
        imglist.add(ImgData(R.drawable.eyes))
        imglist.add(ImgData(R.drawable.hat))
        imglist.add(ImgData(R.drawable.mustache))
        imglist.add(ImgData(R.drawable.shoes))
    }
}

@Composable
fun MainScreen(imgViewModel: ImgViewModel = viewModel()) {
    Text(text = "202114226 송재현")
    val scrollState = rememberScrollState()
    var armsChecked by rememberSaveable { mutableStateOf(false) }
    var eyebrowsChecked by rememberSaveable { mutableStateOf(false) }
    var glassesChecked by rememberSaveable { mutableStateOf(false) }
    var mouthChecked by rememberSaveable { mutableStateOf(false) }
    var noseChecked by rememberSaveable { mutableStateOf(false) }

    var earsChecked by rememberSaveable { mutableStateOf(false) }
    var eyesChecked by rememberSaveable { mutableStateOf(false) }
    var hatChecked by rememberSaveable { mutableStateOf(false) }
    var mustacheChecked by rememberSaveable { mutableStateOf(false) }
    var shoesChecked by rememberSaveable { mutableStateOf(false) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box {
            Image(
                painter = painterResource(id = R.drawable.body),
                contentDescription = "몸",
            )
            if (armsChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[0].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (eyebrowsChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[1].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (glassesChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[2].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (mouthChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[3].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (noseChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[4].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (earsChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[5].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (eyesChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[6].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (hatChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[7].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (mustacheChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[8].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
            if (shoesChecked) {
                Image(
                    painter = painterResource(id = imgViewModel.imglist[9].imgId),
                    contentDescription = "이미지",
                    contentScale = ContentScale.Fit
                )
            }
        }
        Row {
            Column {
                Row {
                    Checkbox(
                        checked = armsChecked,
                        onCheckedChange = {
                            armsChecked = armsChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.arms),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = eyebrowsChecked,
                        onCheckedChange = {
                            eyebrowsChecked = eyebrowsChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.eyebrows),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = glassesChecked,
                        onCheckedChange = {
                            glassesChecked = glassesChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.glasses),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = mouthChecked,
                        onCheckedChange = {
                            mouthChecked = mouthChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.mouth),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = noseChecked,
                        onCheckedChange = {
                            noseChecked = noseChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.nose),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
            }
            Spacer(modifier = Modifier.width(30.dp))

            Column {
                Row {
                    Checkbox(
                        checked = earsChecked,
                        onCheckedChange = {
                            earsChecked = earsChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.ears),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = eyesChecked,
                        onCheckedChange = {
                            eyesChecked = eyesChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.eyes),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = hatChecked,
                        onCheckedChange = {
                            hatChecked = hatChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.hat),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = mustacheChecked,
                        onCheckedChange = {
                            mustacheChecked = mustacheChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.mustache),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
                Row {
                    Checkbox(
                        checked = shoesChecked,
                        onCheckedChange = {
                            shoesChecked = shoesChecked == false
                        })
                    Text(
                        text = stringResource(id = R.string.shoes),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
            }
        }
    }
}
