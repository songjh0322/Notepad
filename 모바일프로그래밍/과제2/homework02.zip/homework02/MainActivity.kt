package com.example.homework02

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.homework02.ui.theme.Homework02Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Homework02Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }

    fun calculateBMI(
        height: Double,
        weight: Double,
        isMeter: Boolean
    ): Any {
        val heightInMeters = if (isMeter) height else height / 100
        var bmi = weight / (heightInMeters * heightInMeters)
        return when {
            bmi < 18.5 -> "저체중"
            bmi < 25 -> "정상"
            bmi < 30 -> "과체중"
            else -> "비만"
        }


    }

    @Composable
    fun EditNumberField(
        value: String,
        onValueChange: (String) -> Unit,
        label: Int
    ) {
        OutlinedTextField(
            value = value,
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Done,
                keyboardType = KeyboardType.Number
            ),
            modifier = Modifier.padding(bottom = 32.dp),
            onValueChange = onValueChange,
            label = { Text(text = stringResource(id = label)) },

            )
    }

    @Composable
    fun SwitchToMeter(
        checked: Boolean,
        onCheckedChange: (Boolean) -> Unit
    ) {
        Row(
            modifier = Modifier.padding(bottom = 32.dp, start = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(id = R.string.switchToMeter)
            )
            Spacer(modifier = Modifier.width(20.dp))
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }

    @Composable
    fun MainScreen() {
        Text(text = "202114226 송재현")

        var heightInput by remember {
            mutableStateOf("")
        }
        var weightInput by remember {
            mutableStateOf("")
        }
        var isMeter by remember {
            mutableStateOf(false)
        }
        val heightLabel = if (isMeter) R.string.heightMeter else R.string.height

        val height = heightInput.toDoubleOrNull() ?: 0.0
        val weight = weightInput.toDoubleOrNull() ?: 0.0
        val bmi = calculateBMI(height, weight, isMeter)

        Column(
            modifier = Modifier.padding(horizontal = 40.dp),
            verticalArrangement = Arrangement.Center
        ) {
            SwitchToMeter(isMeter, { isMeter = it })


            EditNumberField(
                heightInput,
                { heightInput = it },
                heightLabel
            )

            EditNumberField(
                weightInput,
                { weightInput = it },
                R.string.weight
            )

            Row {
                Spacer(modifier = Modifier.width(60.dp))
                Text(
                    text = if (height > 0.0 && weight > 0.0) "$bmi"
                    else stringResource(id = R.string.checkingBMI),
                    modifier = Modifier.padding(bottom = 16.dp),
                    fontSize = 50.sp
                )
            }

            //TextFieldWithHideKeyboardOnImeAction()
        }
    }
}