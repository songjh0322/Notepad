package com.example.mychatgpt.example01.hiltviewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mychatgpt.example01.retrofit.CompletionRequest
import com.example.mychatgpt.example01.retrofit.RetrofitClient
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Exception) : NetworkResult<Nothing>()
}

@Singleton
class ChatGptRepository @Inject constructor() {
    suspend fun getResponse(query: String): NetworkResult<String> {
        val completionRequest = CompletionRequest(
            model = "gpt-3.5-turbo-instruct",
            prompt = query,
            temperature = 0,
            max_tokens = 200
        )
        return try {
            val response = RetrofitClient.apiService.getCompletion(request = completionRequest)
            if (response.isSuccessful) {
                val text = response.body()?.choiceList?.get(0)?.text ?: ""
                NetworkResult.Success(data = text)
            } else {
                NetworkResult.Error(exception = Exception("Network request failed"))
            }
        } catch (e: Exception) {
            NetworkResult.Error(exception = e)
        }
    }
}

@HiltViewModel
class ChatGptViewModel @Inject constructor(private val repository: ChatGptRepository) : ViewModel() {
    private val _response =
        MutableStateFlow<NetworkResult<String>>(NetworkResult.Success(""))
    val response = _response.asStateFlow()

    fun getResponse(query: String) {
        viewModelScope.launch {
            val result = repository.getResponse(query)
            _response.value = result
        }
    }
}