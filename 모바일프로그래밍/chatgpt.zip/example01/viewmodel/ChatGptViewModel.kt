package com.example.mychatgpt.example01.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.mychatgpt.example01.retrofit.CompletionRequest
import com.example.mychatgpt.example01.retrofit.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch


sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Exception) : NetworkResult<Nothing>()
}

class ChatGptRepository{
    suspend fun getResponse(query: String): NetworkResult<String> {
        val completionRequest = CompletionRequest(
            model = "gpt-3.5-turbo-instruct",
            prompt = query,
            temperature = 0,
            max_tokens = 200
        )
        return try {
            val response = RetrofitClient.apiService.getCompletion(request = completionRequest)
            if (response.isSuccessful) {
                val text = response.body()?.choiceList?.get(0)?.text ?: ""
                NetworkResult.Success(data = text)
            } else {
                NetworkResult.Error(exception = Exception("Network request failed"))
            }
        } catch (e: Exception) {
            NetworkResult.Error(exception = e)
        }
    }
}

class ChatGptViewModel (private val repository: ChatGptRepository) : ViewModel() {
    private val _response =
        MutableStateFlow<NetworkResult<String>>(NetworkResult.Success(""))

    val response = _response.asStateFlow()

    fun getResponse(query: String) {
        viewModelScope.launch {
            val result = repository.getResponse(query)
            _response.value = result
        }
    }
}

class ChatGptViewModelFactory(private val repository: ChatGptRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatGptViewModel::class.java)) {
            return ChatGptViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}